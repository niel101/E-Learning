-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 17, 2018 at 10:22 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE IF NOT EXISTS `activity_log` (
  `activity_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  PRIMARY KEY (`activity_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `activity_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `class`
--


-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `Access` varchar(20) NOT NULL,
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`content_id`, `title`, `content`, `Access`) VALUES
(1, 'Mission', 'Mission																					', 'Disable'),
(2, 'Vision', '', 'Disable'),
(3, 'History', '', ''),
(4, 'Footer', '', ''),
(5, 'Upcoming Events', '', ''),
(6, 'Title', '', ''),
(7, 'News', '', ''),
(8, 'Announcements', '', ''),
(10, 'Calendar', '', ''),
(11, 'Directories', '', ''),
(12, 'president', '', ''),
(13, 'motto', '', ''),
(14, 'Campuses', '', ''),
(16, 'Unit 1', '																																																	<h1>Unit 1 : COURSE OVERVIEW</h1>\r\n\r\nIntroduction In Visual Basic. NET\r\n	Students Learn basic programming and the essential concepts of Visual Basic. Net (VB.Net) in this course .As an introduction to Vb .Net, students are taught the basic uses of the programming language, its similarities to the English Language and others, its architecture, program flow, and its flexibility as a programming language. The course helps participants understand the processes involved in software development and object oriented programming. This is an introductory course that could lead to careers such as software engineer, developer, or game designer. Prior coursework in computer fundamentals is a prerequisite.<br><br>\r\n\r\n1.1 The concept of computer programming\r\nProgramming means writing coded instructions or programs to instruct a computer or other devices to perform specific tasks automatically. The computer programs written by the programmers are often known as software .Various software exist today, among them are desktop operating system, Internet browsers, spreadsheet, word processing software, accounting software, photo and video editing software, gaming software, mobile apps, robotic software and more. In order to create a computer program, we need to use a programming language. The earliest programming language is called machine language which uses the binary code(comprises 0 and 1) to communicate with the computer. However, the machine language is extremely difficult to learn .Fortunately , scientists have invented some high-level programming languages that are much easier to master. Among the high-level programming languages are Java, Javascript, C, C++, c# and Visual Basic.\r\n <br><br><br>\r\n<img src="tabo/elearning.png" height="300px" width="320px" >								\r\n																																																												', 'Unable'),
(18, 'da', '										\r\n		adadadadad										', 'Unable'),
(19, 'samle', 'sample										\r\n												', 'Disable');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) NOT NULL,
  `dean` varchar(100) NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `dean`) VALUES
(4, 'College of Industrial Technology', 'Dr. Antonio Deraja'),
(5, 'School of Arts and Science', 'DR.'),
(9, 'College of Education', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_title` varchar(100) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `date_start` varchar(100) NOT NULL,
  `date_end` varchar(100) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_title`, `teacher_class_id`, `date_start`, `date_end`) VALUES
(15, 'Long Test', 113, '12/05/2013', '12/06/2013'),
(17, 'sdasf', 147, '11/16/2013', '11/16/2013'),
(18, 'ipapasa ko yung E-Learning System', 0, 'June 18, 2018', 'June 19, 20 18');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_code`
--

CREATE TABLE IF NOT EXISTS `lesson_code` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `lesson_code`
--

INSERT INTO `lesson_code` (`student_id`, `name`, `code`, `status`) VALUES
(1, 'unit1', '2', 'Disable'),
(2, 'sample', '2', 'Unable');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `que_id` int(5) NOT NULL AUTO_INCREMENT,
  `test_id` int(5) NOT NULL,
  `que_desc` mediumtext NOT NULL,
  `ans1` varchar(50) NOT NULL,
  `ans2` varchar(50) NOT NULL,
  `ans3` varchar(50) NOT NULL,
  `ans4` varchar(50) NOT NULL,
  `true_ans` int(1) NOT NULL,
  PRIMARY KEY (`que_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`que_id`, `test_id`, `que_desc`, `ans1`, `ans2`, `ans3`, `ans4`, `true_ans`) VALUES
(3, 10, '	________________ is a third-generation event-driven programming language first released by Microsoft in 1991.', 'a.C#  ', 'b.Visual Basic', 'c.Python ', 'd.C++', 2),
(4, 10, 'The ______ bar is the bar is at the very top of the editing window.  It consists of the dropdown menus: File, Edit, View, Project, Build, Debug, Data, Tools, Window, andHelp.  ', 'a.	C#  ', 'b. Visual Basic	', 'c. Toolbar 	', 'd. C++', 3),
(5, 10, '	________ box contains the tools you use to place various controls on your forms', 'a.Label	', 'b. Visual Basic	', 'c. Toolbar', 'd. C++', 1),
(6, 10, '_____________ used to create a button that the user can choose to carry out a command', 'a.)  Link ', 'b. Label	', 'c. Toolbar', 'd. Command button', 4),
(7, 10, '_____________ used in a group of option buttons to display multiple choices from which the user can choose only one.  ', 'a.)  Link ', 'b. Label', 'c. Toolbar', 'd.        Radio Button', 4),
(8, 10, '______________used to display graphical images (either decorative or active), as a container that receives output from graphics methods, or as a container for other controls', 'a.)  Link ', 'b.Picture Box', 'c. Toolbar', 'd.        Radio Button', 2),
(9, 10, '______________used to draw a combination list box and text box. The user can either choose an item from the list or enter a value in the text box.  ', 'a.)  Link ', 'b.Picture Box', 'c. Combo Box', 'd. Radio Button', 3),
(10, 10, '.)______________ used to host or hold other controls that belong to the same group', 'a.)  Link ', 'b.Picture Box', 'c. Combo Box', 'd.  Panel', 4),
(11, 10, '.) _______________ used to Displays a list of items with icons, similar to Windows explorer.', 'a.)  Link ', 'b.Picture Box', 'c. Combo Box', 'd. List View', 4),
(12, 10, '.)_____________ used to set to indicate the progress of a process by displaying the status in the form of small rectangles in a long rectangle.', 'a.)  Link ', 'b.Progress Bar', 'c. Combo Box	', 'd.       List View', 2),
(13, 11, 'Used in a group of option buttons to display multiple choices from which the user can choose only one.', 'a.Textbox', 'b.Main menu', 'c.Checkbox', 'd.GroupBox', 1),
(14, 11, 'Typically used to serve as a border for control with similar needs ', 'a.Textbox', 'b.Main menu', 'c. Toolbar ', 'd.       List View', 2),
(15, 11, 'Used to display graphical images (either decorative or active), as a container that receives output from graphics methods, or as a container for other controls', 'a.Textbox', 'b.Chechbox', 'c.Radio button', 'd.Button', 2),
(16, 11, 'Used to hold text that the user can either enter or change.', 'a.Textbox', 'b. Radio button', 'c. Combo Box', 'd.button', 2),
(17, 11, 'Adds menus under the titles bar of the form.i.e. File, Edit, … ', 'a.Label', 'b.Picture Box', 'c.Groupbox', 'd.Panel', 3),
(18, 11, 'Used to create a box that the user can easily choose to indicate if something is true or false, or to display multiple choices when the user can choose more than one.', 'a.Radio button', 'b.Chechbox', 'c. Combo Box', 'd.Picturebox', 4),
(19, 11, 'Allows the user to choose the current font color', 'a.Color Dialog: ', 'b.Print Dialog: ', 'c.Print Preview Dialog: ', 'd.Print Preview Control', 1),
(20, 11, 'Brings up the typical Windows print menu ', 'a.Color Dialog: ', 'b.Print Dialog: ', 'c.Print Preview Dialog: ', 'd.Print Preview Control', 2),
(21, 11, 'Opens the menu window for Print Preview settings ', 'a.Color Dialog: ', 'b.Print Preview Dialog: ', 'c.Color Dialog: ', 'dPrint Preview Control:', 2),
(22, 11, 'Print Preview Control:', 'a.Allows the user to choose the current font color', 'b.Brings up the typical Windows print menu ', 'c.Opens the menu window for Print Preview settings', 'd.Opens print preview with the default settings ', 4),
(23, 13, '________________ it is the step by step procedure or systematic approach to develop software.', 'a.Life Cycle', 'b.	Spiral  ', 'c.Agile', 'd. Sdlc', 4),
(24, 13, 'SDLC is also known as ?', 'a. Software Development Process', 'b. Software Development Process', 'c.System Development Life Circle', 'd.System Development Life Cycle', 4),
(25, 13, '________ it is basic mode of SDLC which is also known as mother of all other model?', 'a. Waterfall Model', 'b. SDLC', 'c.Spiral Model', 'd. V Model', 1),
(26, 13, 'A software project repeatedly goes through each phases in iterations hence it is called ________?.', 'a.    Spiral Model', 'b. Agile Model', 'c. V Model', '.d. Iterative Model', 1);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `id` varchar(50) NOT NULL,
  `test_id` int(5) NOT NULL,
  `score` int(3) NOT NULL,
  `test_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `test_id`, `score`, `test_date`) VALUES
('223', 10, 1, '0000-00-00'),
('221', 10, 1, '0000-00-00'),
('229', 10, 9, '0000-00-00'),
('229', 11, 1, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `login` varchar(50) NOT NULL,
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `class_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=232 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`login`, `student_id`, `firstname`, `lastname`, `class_id`, `username`, `password`, `location`, `status`) VALUES
('', 220, 'Juan', 'San juan', 0, 'solidAccess', 'niel', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
('', 221, 'Maria nicole hailee', 'Borjal', 0, '111', 'niel', 'uploads/Project_Manager.jpg', 'Registered'),
('', 223, 'Jose', 'Manalo', 0, '111', 'manalosana', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
('', 230, 'sample', 'sample', 0, 'sample', 'sample', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
('', 227, 'Max', 'Collins', 0, 'maxloves', 'mymax', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
('', 229, 'E-Learning', 'Student', 0, 'student', 'student', 'uploads/learning-button_0.png', 'Registered'),
('', 231, 'dos', 'dos', 0, 'dos', 'dos', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered');

-- --------------------------------------------------------

--
-- Table structure for table `studentanswer`
--

CREATE TABLE IF NOT EXISTS `studentanswer` (
  `sess_id` varchar(50) NOT NULL,
  `test_id` int(11) NOT NULL,
  `que_des` mediumtext NOT NULL,
  `ans1` varchar(50) NOT NULL,
  `ans2` varchar(50) NOT NULL,
  `ans3` varchar(50) NOT NULL,
  `ans4` varchar(50) NOT NULL,
  `true_ans` int(11) NOT NULL,
  `your_ans` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentanswer`
--


-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(50) NOT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`) VALUES
(21, 'Unit 1'),
(22, 'Unit 2 Software Development'),
(23, 'Easy');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  `location` varchar(200) NOT NULL,
  `about` varchar(500) NOT NULL,
  `teacher_status` varchar(20) NOT NULL,
  `teacher_stat` varchar(100) NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `username`, `password`, `firstname`, `lastname`, `department_id`, `location`, `about`, `teacher_status`, `teacher_stat`) VALUES
(15, 'teacher', 'teacher', 'E-Learning ', 'Teacher', 0, 'uploads/eLearning-sm-clearbkgrnd (1)-2.png', '', '', 'Activated'),
(20, 'maria', 'maria', 'Maria nicole hailee', 'Borjal', 0, 'uploads/notep1.jpg', '', '', 'Activated');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `test_id` int(5) NOT NULL AUTO_INCREMENT,
  `sub_id` int(5) NOT NULL,
  `test_name` varchar(50) NOT NULL,
  `total_que` varchar(50) NOT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`test_id`, `sub_id`, `test_name`, `total_que`) VALUES
(13, 22, 'Quiz 1', '20'),
(11, 21, 'Quiz 2', '10'),
(10, 21, 'Quiz 1', '10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`) VALUES
(15, 'admin', 'admin', 'admin', 'admin'),
(25, 'niel', 'niel', 'Ronnel', 'Borjal');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE IF NOT EXISTS `user_log` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=130 ;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `user_id`) VALUES
(1, 'admin', '2013-11-01 11:57:33', '2013-11-18 10:33:54', 10),
(2, 'admin', '2013-11-05 09:52:09', '2013-11-18 10:33:54', 10),
(3, 'admin', '2013-11-08 10:41:09', '2013-11-18 10:33:54', 10),
(4, 'admin', '2013-11-12 22:53:05', '2013-11-18 10:33:54', 10),
(5, 'admin', '2013-11-13 07:07:04', '2013-11-18 10:33:54', 10),
(6, 'admin', '2013-11-13 13:07:58', '2013-11-18 10:33:54', 10),
(7, 'admin', '2013-11-13 13:30:45', '2013-11-18 10:33:54', 10),
(8, 'admin', '2013-11-13 15:25:20', '2013-11-18 10:33:54', 10),
(9, 'admin', '2013-11-13 15:46:28', '2013-11-18 10:33:54', 10),
(10, 'admin', '2013-11-13 16:04:10', '2013-11-18 10:33:54', 10),
(11, 'admin', '2013-11-13 17:31:37', '2013-11-18 10:33:54', 10),
(12, 'admin', '2013-11-13 22:47:45', '2013-11-18 10:33:54', 10),
(13, 'admin', '2013-11-14 10:27:06', '2013-11-18 10:33:54', 10),
(14, 'admin', '2013-11-14 10:27:55', '2013-11-18 10:33:54', 10),
(15, 'admin', '2013-11-14 10:38:08', '2013-11-18 10:33:54', 10),
(16, 'admin', '2013-11-14 10:38:09', '2013-11-18 10:33:54', 10),
(17, 'admin', '2013-11-14 10:41:06', '2013-11-18 10:33:54', 10),
(18, 'admin', '2013-11-14 11:44:08', '2013-11-18 10:33:54', 10),
(19, 'admin', '2013-11-14 21:53:56', '2013-11-18 10:33:54', 10),
(20, 'admin', '2013-11-14 22:03:53', '2013-11-18 10:33:54', 10),
(31, 'teph', '2013-11-23 12:02:27', '2013-11-30 21:33:02', 13),
(32, 'teph', '2013-11-24 08:55:55', '2013-11-30 21:33:02', 13),
(33, 'jkev', '2013-11-25 10:32:16', '2014-02-13 11:19:36', 14),
(34, 'jkev', '2013-11-25 14:33:05', '2014-02-13 11:19:36', 14),
(35, 'jkev', '2013-11-25 15:02:47', '2014-02-13 11:19:36', 14),
(36, 'jkev', '2013-11-25 21:08:19', '2014-02-13 11:19:36', 14),
(37, 'jkev', '2013-11-25 23:49:58', '2014-02-13 11:19:36', 14),
(38, 'jkev', '2013-11-26 00:32:22', '2014-02-13 11:19:36', 14),
(39, 'jkev', '2013-11-26 10:39:52', '2014-02-13 11:19:36', 14),
(40, 'jkev', '2013-11-26 21:48:05', '2014-02-13 11:19:36', 14),
(41, 'jkev', '2013-11-28 23:00:00', '2014-02-13 11:19:36', 14),
(42, 'jkev', '2013-11-28 23:00:06', '2014-02-13 11:19:36', 14),
(43, 'jkev', '2013-11-30 21:28:54', '2014-02-13 11:19:36', 14),
(44, 'teph', '2013-11-30 21:32:54', '2013-11-30 21:33:02', 13),
(45, 'jkev', '2013-12-04 12:45:09', '2014-02-13 11:19:36', 14),
(46, 'teph', '2013-12-04 14:02:19', '', 13),
(47, 'jkev', '2013-12-11 11:56:15', '2014-02-13 11:19:36', 14),
(48, 'jkev', '2013-12-11 12:04:44', '2014-02-13 11:19:36', 14),
(49, 'jkev', '2013-12-12 09:44:34', '2014-02-13 11:19:36', 14),
(50, 'jkev', '2013-12-13 01:48:23', '2014-02-13 11:19:36', 14),
(51, 'jkev', '2013-12-27 09:13:20', '2014-02-13 11:19:36', 14),
(52, 'jkev', '2013-12-27 10:18:38', '2014-02-13 11:19:36', 14),
(53, 'jkev', '2013-12-27 10:35:43', '2014-02-13 11:19:36', 14),
(54, 'jkev', '2013-12-27 11:08:54', '2014-02-13 11:19:36', 14),
(55, 'jkev', '2013-12-27 11:20:25', '2014-02-13 11:19:36', 14),
(56, 'jkev', '2013-12-27 11:41:58', '2014-02-13 11:19:36', 14),
(57, 'jkev', '2013-12-27 11:43:10', '2014-02-13 11:19:36', 14),
(58, 'jkev', '2013-12-27 14:54:57', '2014-02-13 11:19:36', 14),
(59, 'jkev', '2014-01-12 20:08:26', '2014-02-13 11:19:36', 14),
(60, 'jkev', '2014-01-13 15:24:07', '2014-02-13 11:19:36', 14),
(61, 'jkev', '2014-01-13 18:46:08', '2014-02-13 11:19:36', 14),
(62, 'jkev', '2014-01-15 20:40:15', '2014-02-13 11:19:36', 14),
(63, 'jkev', '2014-01-16 14:42:02', '2014-02-13 11:19:36', 14),
(64, 'jkev', '2014-01-17 09:16:17', '2014-02-13 11:19:36', 14),
(65, 'jkev', '2014-01-17 13:25:51', '2014-02-13 11:19:36', 14),
(66, 'admin', '2014-01-17 14:41:30', '2018-06-16 13:41:13', 15),
(67, 'admin', '2014-01-17 15:56:32', '2018-06-16 13:41:13', 15),
(68, 'admin', '2014-01-26 17:45:31', '2018-06-16 13:41:13', 15),
(69, 'admin', '2014-02-13 10:45:17', '2018-06-16 13:41:13', 15),
(70, 'admin', '2014-02-13 11:05:27', '2018-06-16 13:41:13', 15),
(71, 'jkev', '2014-02-13 11:16:48', '2014-02-13 11:19:36', 14),
(72, 'admin', '2014-02-13 11:55:36', '2018-06-16 13:41:13', 15),
(73, 'admin', '2014-02-13 12:32:38', '2018-06-16 13:41:13', 15),
(74, 'admin', '2014-02-13 12:52:05', '2018-06-16 13:41:13', 15),
(75, 'admin', '2014-02-13 13:04:35', '2018-06-16 13:41:13', 15),
(76, 'jkev', '2014-02-13 14:35:27', '', 14),
(77, 'admin', '2014-02-20 09:40:39', '2018-06-16 13:41:13', 15),
(78, 'admin', '2014-02-20 09:42:21', '2018-06-16 13:41:13', 15),
(79, 'admin', '2014-02-27 22:40:15', '2018-06-16 13:41:13', 15),
(80, 'admin', '2014-02-28 13:12:52', '2018-06-16 13:41:13', 15),
(81, 'admin', '2014-04-02 17:27:47', '2018-06-16 13:41:13', 15),
(82, 'admin', '2014-04-03 15:29:38', '2018-06-16 13:41:13', 15),
(83, 'admin', '2014-06-15 12:31:51', '2018-06-16 13:41:13', 15),
(84, 'admin', '2018-06-06 06:01:36', '2018-06-16 13:41:13', 15),
(85, 'admin', '2018-06-09 12:26:02', '2018-06-16 13:41:13', 15),
(86, 'admin', '2018-06-09 12:46:11', '2018-06-16 13:41:13', 15),
(87, 'admin', '2018-06-09 22:03:09', '2018-06-16 13:41:13', 15),
(88, 'admin', '2018-06-09 23:14:35', '2018-06-16 13:41:13', 15),
(89, 'admin', '2018-06-10 01:44:21', '2018-06-16 13:41:13', 15),
(90, 'admin', '2018-06-10 01:46:59', '2018-06-16 13:41:13', 15),
(91, 'admin', '2018-06-10 10:03:15', '2018-06-16 13:41:13', 15),
(92, 'admin', '2018-06-10 18:04:41', '2018-06-16 13:41:13', 15),
(93, 'admin', '2018-06-10 18:11:20', '2018-06-16 13:41:13', 15),
(94, 'admin', '2018-06-10 18:18:38', '2018-06-16 13:41:13', 15),
(95, 'admin', '2018-06-14 17:06:45', '2018-06-16 13:41:13', 15),
(96, 'admin', '2018-06-14 21:24:05', '2018-06-16 13:41:13', 15),
(97, 'admin', '2018-06-14 22:26:47', '2018-06-16 13:41:13', 15),
(98, 'admin', '2018-06-14 22:47:07', '2018-06-16 13:41:13', 15),
(99, 'admin', '2018-06-14 23:06:56', '2018-06-16 13:41:13', 15),
(100, 'admin', '2018-06-14 23:11:40', '2018-06-16 13:41:13', 15),
(101, 'admin', '2018-06-14 23:38:36', '2018-06-16 13:41:13', 15),
(102, 'admin', '2018-06-14 23:39:33', '2018-06-16 13:41:13', 15),
(103, 'admin', '2018-06-14 23:42:09', '2018-06-16 13:41:13', 15),
(104, 'admin', '2018-06-15 00:19:00', '2018-06-16 13:41:13', 15),
(105, 'admin', '2018-06-15 00:29:11', '2018-06-16 13:41:13', 15),
(106, 'admin', '2018-06-15 02:33:43', '2018-06-16 13:41:13', 15),
(107, 'admin', '2018-06-15 02:45:51', '2018-06-16 13:41:13', 15),
(108, 'admin', '2018-06-15 12:43:20', '2018-06-16 13:41:13', 15),
(109, 'admin', '2018-06-15 15:38:12', '2018-06-16 13:41:13', 15),
(110, 'admin', '2018-06-15 15:38:24', '2018-06-16 13:41:13', 15),
(111, 'admin', '2018-06-15 19:05:14', '2018-06-16 13:41:13', 15),
(112, 'admin', '2018-06-15 20:14:39', '2018-06-16 13:41:13', 15),
(113, 'admin', '2018-06-15 22:12:44', '2018-06-16 13:41:13', 15),
(114, 'admin', '2018-06-16 01:18:12', '2018-06-16 13:41:13', 15),
(115, 'admin', '2018-06-16 01:32:34', '2018-06-16 13:41:13', 15),
(116, 'admin', '2018-06-16 01:56:22', '2018-06-16 13:41:13', 15),
(117, 'admin', '2018-06-16 02:15:39', '2018-06-16 13:41:13', 15),
(118, 'admin', '2018-06-16 13:18:44', '2018-06-16 13:41:13', 15),
(119, 'admin', '2018-06-16 13:21:53', '2018-06-16 13:41:13', 15),
(120, 'admin', '2018-06-16 13:58:42', '', 15),
(121, 'admin', '2018-06-16 21:41:09', '', 15),
(122, 'admin', '2018-06-16 23:11:19', '', 15),
(123, 'admin', '2018-06-16 23:21:34', '', 15),
(124, 'admin', '2018-06-17 01:12:50', '', 15),
(125, 'admin', '2018-06-17 01:15:33', '', 15),
(126, 'admin', '2018-06-17 02:14:27', '', 15),
(127, 'admin', '2018-06-17 17:01:43', '', 15),
(128, 'admin', '2018-06-17 17:37:13', '', 15),
(129, 'admin', '2018-06-17 19:49:42', '', 15);
